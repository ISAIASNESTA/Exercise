import React, { useState } from "react";

const routine = {
  Lunes: "Pecho (máquinas) + Abdomen",
  Martes: "Brazos + Glúteos",
  Miércoles: "Pecho (máquinas) + Abdomen",
  Jueves: "Glúteos + Abdomen",
  Viernes: "Pecho (máquinas) + Brazos",
  Sábado: "Abdomen + Glúteos",
  Domingo: "Cardio suave (descanso activo)"
};

const details = {
  Lunes: ["Press plano máquina 4x10", "Press inclinado máquina 4x12", "Peck-deck 4x15", "Press declinado máquina 3x12", "Crunch máquina 4x20", "Elevación piernas 4x15", "Plancha 3x1min", "Russian twists 3x30seg"],
  Martes: ["Curl predicador 4x10", "Curl polea baja 3x12", "Curl martillo cuerda 3x12", "Jalón polea 4x12", "Extensión máquina 3x10", "Patada polea 3x15", "Hip thrust 4x15", "Sentadilla Smith 4x12", "Patada trasera máquina 3x15"],
  Miércoles: ["Superset Press plano + Peck-deck 4x12", "Press inclinado máquina 4x10", "Crossover polea 3x15", "Crunch con disco 3x20", "Plancha lateral 2x30seg", "Rueda abdominal 3x10", "Escaladores 3x30seg"],
  Jueves: ["Peso muerto rumano 4x12", "Zancadas con barra 3x12", "Abducción máquina 4x20", "Hip thrust pausa 3x10", "Crunch bicicleta 3x30seg", "Crunch máquina 3x15", "Plancha con pierna 3x30seg"],
  Viernes: ["Press pecho máquina 4x10", "Peck-deck 3x15", "Crossover polea baja 3x12", "Curl + fondos máquina 3x12", "Curl predicador + extensión polea 3x10"],
  Sábado: ["Crunch polea alta 4x15", "Plancha dinámica 3x45seg", "Elevaciones colgado 3x12", "Step-ups 3x12", "Sentadilla salto 3x15", "Monster walk banda 3x30 pasos"],
  Domingo: ["Cardio: caminata, yoga o estiramiento profundo"]
};

export default function App() {
  const [day, setDay] = useState("Lunes");

  return (
    <div style={{ padding: 20, fontFamily: "Arial" }}>
      <h1 style={{ fontSize: 20, fontWeight: "bold" }}>Rutina Semanal</h1>
      <select value={day} onChange={(e) => setDay(e.target.value)} style={{ margin: "10px 0", padding: 5 }}>
        {Object.keys(routine).map((d) => (
          <option key={d} value={d}>{d}</option>
        ))}
      </select>
      <h2>{day} - {routine[day]}</h2>
      <ul>
        {details[day].map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
}